def test(arg1, arg2):
    print("arg1, arg2: ",arg1, arg2)